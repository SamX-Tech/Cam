package com.example.cam;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.view.Surface;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

public class RecordingService extends Service {
    public static final String ACTION_START = "com.example.cam.START";
    public static final String ACTION_STOP = "com.example.cam.STOP";
    private static final String CHANNEL_ID = "cam_recording";
    private static final int NOTIFICATION_ID = 7;

    private HandlerThread thread;
    private Handler handler;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private MediaRecorder recorder;
    private boolean isRecording = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopRecording();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        if (thread == null) {
            thread = new HandlerThread("CamCameraThread");
            thread.start();
            handler = new Handler(thread.getLooper());
        }
        openCamera();
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        return new Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("Cam is recording")
            .setContentText("Video is being saved on this device")
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Cam recording", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows when Cam is actively recording video.");
            channel.setShowBadge(false);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void openCamera() {
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }
        try {
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String chosenId = null;
            for (String id : manager.getCameraIdList()) {
                android.hardware.camera2.CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Integer facing = c.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK) {
                    chosenId = id;
                    break;
                }
            }
            if (chosenId == null) {
                String[] ids = manager.getCameraIdList();
                if (ids.length > 0) chosenId = ids[0];
            }
            if (chosenId == null) {
                stopSelf();
                return;
            }
            manager.openCamera(chosenId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice device) {
                    camera = device;
                    prepareRecorderAndSession();
                }
                @Override public void onDisconnected(CameraDevice device) {
                    device.close();
                    camera = null;
                    stopSelf();
                }
                @Override public void onError(CameraDevice device, int error) {
                    device.close();
                    camera = null;
                    stopSelf();
                }
            }, handler);
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void prepareRecorderAndSession() {
        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            if (dir == null) dir = getFilesDir();
            if (!dir.exists()) dir.mkdirs();
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File output = new File(dir, "Cam_" + stamp + ".mp4");

            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setOutputFile(output.getAbsolutePath());
            recorder.setVideoEncodingBitRate(5_000_000);
            recorder.setVideoFrameRate(30);
            recorder.setVideoSize(1280, 720);
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.prepare();

            Surface surface = recorder.getSurface();
            camera.createCaptureSession(Collections.singletonList(surface),
                new CameraCaptureSession.StateCallback() {
                    @Override public void onConfigured(CameraCaptureSession configured) {
                        session = configured;
                        try {
                            CaptureRequest.Builder request = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
                            request.addTarget(surface);
                            session.setRepeatingRequest(request.build(), null, handler);
                            recorder.start();
                            isRecording = true;
                            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                            nm.notify(NOTIFICATION_ID, buildNotification());
                        } catch (Exception e) {
                            stopRecording();
                            stopSelf();
                        }
                    }
                    @Override public void onConfigureFailed(CameraCaptureSession failed) {
                        stopRecording();
                        stopSelf();
                    }
                }, handler);
        } catch (Exception e) {
            stopRecording();
            stopSelf();
        }
    }

    private void stopRecording() {
        try {
            if (session != null) {
                session.stopRepeating();
                session.close();
                session = null;
            }
        } catch (Exception ignored) {}
        if (recorder != null) {
            try { if (isRecording) recorder.stop(); } catch (Exception ignored) {}
            try { recorder.reset(); recorder.release(); } catch (Exception ignored) {}
            recorder = null;
        }
        isRecording = false;
        if (camera != null) {
            try { camera.close(); } catch (Exception ignored) {}
            camera = null;
        }
        if (thread != null) {
            thread.quitSafely();
            thread = null;
            handler = null;
        }
    }

    @Override
    public void onDestroy() {
        stopRecording();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
