package com.example.cam;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 41;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Cam");
        title.setTextSize(32);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        status = new TextView(this);
        status.setText("Ready. Start recording while the app is open.");
        status.setTextSize(16);
        status.setPadding(0, 24, 0, 24);
        layout.addView(status);

        Button start = new Button(this);
        start.setText("Start recording");
        start.setOnClickListener(v -> requestAndStart());
        layout.addView(start);

        Button stop = new Button(this);
        stop.setText("Stop recording");
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, RecordingService.class);
            intent.setAction(RecordingService.ACTION_STOP);
            startService(intent);
            status.setText("Stop requested.");
        });
        layout.addView(stop);

        TextView note = new TextView(this);
        note.setText("Start recording while Cam is open. Wait for the recording notification before locking the phone. Android's recording notification and privacy indicators remain active.");
        note.setTextSize(13);
        note.setPadding(0, 28, 0, 0);
        layout.addView(note);

        setContentView(layout);
    }

    private void requestAndStart() {
        boolean camera = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (!camera || !mic) {
            requestPermissions(new String[] {
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
            }, REQUEST_PERMISSIONS);
            return;
        }
        startRecordingService();
    }

    private void startRecordingService() {
        Intent intent = new Intent(this, RecordingService.class);
        intent.setAction(RecordingService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        status.setText("Starting camera… Wait for the recording notification before locking the phone.");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean granted = grantResults.length >= 2
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
                && grantResults[1] == PackageManager.PERMISSION_GRANTED;
            if (granted) startRecordingService();
            else status.setText("Camera and microphone permissions are required.");
        }
    }
}
