# Cam — Android starter project

A minimal Android video recorder project targeting Android 11-era devices.

## Current behavior
- Starts from a visible app screen.
- Requests camera and microphone permission.
- Starts a camera foreground service and displays an ongoing recording notification.
- Uses the rear camera and records MP4 video with audio.
- After recording has started, you can test whether the Realme firmware allows it to continue while the screen is locked.
- Stop by reopening Cam and pressing **Stop recording**.

Android's recording notification and camera/microphone privacy indicators remain active. This project does not suppress them.

## Recording location
Videos are stored in the app-specific Movies directory:
`Android/data/com.example.cam/files/Movies`

## Build without a PC
1. Create a GitHub repository and upload the contents of this ZIP.
2. Open the repository's **Actions** tab.
3. Run **Build Cam APK** (or push to `main`).
4. Download the `Cam-debug-apk` artifact.
5. Install the APK on the Realme 9i and grant camera/microphone permissions.

## Important limitations
This is a starter implementation, not a tested build for the Realme 9i. The selected 1280x720 camera mode may not be supported by every camera. Screen-lock behavior depends on Realme UI power management and Android camera-service rules. Test with a short recording first.
